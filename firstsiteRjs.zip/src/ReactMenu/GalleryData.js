import g1 from '../images/g1.jpeg'
import g2 from '../images/g2.jpeg'
import g3 from '../images/g3.jpeg'
import g4 from '../images/g4.jpeg'
import g5 from '../images/g5.jpeg'
import g6 from '../images/g6.jpeg'
import g7 from '../images/g7.jpeg'
import g8 from '../images/g8.jpeg'
import g9 from '../images/g9.jpeg'
import g10 from '../images/g10.jpeg'
import g11 from '../images/g11.jpeg'
import g12 from '../images/g12.jpeg'


const GalleryData = [
    {
        imgsrc: g1
    },
    {
        imgsrc: g2
    },
    {
        imgsrc: g3
    },
    {
        imgsrc: g4
    },
    {
        imgsrc: g5
    },
    {
        imgsrc: g6
    },
    {
        imgsrc: g7
    },
    {
        imgsrc: g8
    },
    {
        imgsrc: g9
    },
    {
        imgsrc: g10
    },
    {
        imgsrc: g11
    },
    {
        imgsrc: g12
    }
]

export default GalleryData